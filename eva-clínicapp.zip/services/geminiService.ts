
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const summarizeClinicalHistory = async (formData: Record<string, any>): Promise<string> => {
  const prompt = `
    Como experta en acompañamiento de lactancia y crianza, resume esta situación familiar de forma empática y clara.
    Enfócate en los desafíos que enfrenta la mamá y los puntos donde necesita más apoyo.
    Datos del registro: ${JSON.stringify(formData)}
    Usa un tono cálido y humano. No uses lenguaje médico frío.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "No se pudo generar el resumen.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error al conectar con el asistente de IA.";
  }
};

export const suggestActionPlan = async (context: string): Promise<string> => {
  const prompt = `
    Basado en este contexto de consulta: "${context}"
    Sugiere una serie de pasos prácticos, calmados y empáticos para la familia. 
    Incluye:
    1. Ideas para el día a día.
    2. Técnicas de consuelo o lactancia suaves.
    3. Señales de que todo fluye bien.
    Usa un lenguaje muy cercano y alentador.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
    });
    return response.text || "No se pudo generar la guía.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error al generar la guía de acompañamiento.";
  }
};
